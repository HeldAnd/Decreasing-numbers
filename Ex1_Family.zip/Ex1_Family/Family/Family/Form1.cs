﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Family
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void inBox_TextChanged(object sender, EventArgs e)
        {


            Data ni = new Data();


        }

        private void calButton_Click(object sender, EventArgs e)
        {
            

            Data ni = new Data();

            

            //------------------------------------------------------

            // CHECK

            ni.TestS = false;

            while (ni.TestS == false)
            {

                if (String.IsNullOrWhiteSpace(inBox.Text))
                {
                    MessageBox.Show("Please, informe the number");
                    return;
                }


                else
                {

                    ni.TestS = true;

                }
            }

            //------------------------------------------------------


            ni.Number = int.Parse(inBox.Text);


            // LOGIC

            if (ni.Number < 10)
            {
                ni.Result1 = ((ni.Number / 1) % 10);
                ni.Family = ni.Result1;

            }
            else if (ni.Number < 100 && ni.Number >= 10 )
            {
                ni.Result1 = ((ni.Number / 1) % 10);
                ni.Result2 = ((ni.Number / 10) % 10);

                int[] array2 = new int[] { ni.Result1, ni.Result2 };

                array2 = array2.OrderByDescending(c => c).ToArray();

                ni.Value = array2.Aggregate(string.Empty, (s, i) => s + i.ToString());

                ni.Family = Int32.Parse(ni.Value);

            }
            else if (ni.Number < 1000 && ni.Number >= 100)
            {
                ni.Result1 = ((ni.Number / 1) % 10);
                ni.Result2 = ((ni.Number / 10) % 10);
                ni.Result3 = ((ni.Number / 100) % 10);

                int[] array3 = new int[] { ni.Result1, ni.Result2, ni.Result3 };

                array3 = array3.OrderByDescending(c => c).ToArray();

                ni.Value = array3.Aggregate(string.Empty, (s, i) => s + i.ToString());

                ni.Family = Int32.Parse(ni.Value);

            }
            else if (ni.Number < 10000 && ni.Number >= 1000)
            {
                ni.Result1 = ((ni.Number / 1) % 10);
                ni.Result2 = ((ni.Number / 10) % 10);
                ni.Result3 = ((ni.Number / 100) % 10);
                ni.Result4 = ((ni.Number / 1000) % 10);

                int[] array4 = new int[] { ni.Result1, ni.Result2, ni.Result3, ni.Result4 };

                array4 = array4.OrderByDescending(c => c).ToArray();

                ni.Value = array4.Aggregate(string.Empty, (s, i) => s + i.ToString());

                ni.Family = Int32.Parse(ni.Value);

            }

            else if (ni.Number < 100000 && ni.Number >= 10000)
            {
                ni.Result1 = ((ni.Number / 1) % 10);
                ni.Result2 = ((ni.Number / 10) % 10);
                ni.Result3 = ((ni.Number / 100) % 10);
                ni.Result4 = ((ni.Number / 1000) % 10);
                ni.Result5 = ((ni.Number / 10000) % 10);

                int[] array5 = new int[] { ni.Result1, ni.Result2, ni.Result3, ni.Result4, ni.Result5 };

                array5 = array5.OrderByDescending(c => c).ToArray();

                ni.Value = array5.Aggregate(string.Empty, (s, i) => s + i.ToString());

                ni.Family = Int32.Parse(ni.Value);


            }
            else if (ni.Number < 1000000 && ni.Number >= 100000)
            {
                ni.Result1 = ((ni.Number / 1) % 10);
                ni.Result2 = ((ni.Number / 10) % 10);
                ni.Result3 = ((ni.Number / 100) % 10);
                ni.Result4 = ((ni.Number / 1000) % 10);
                ni.Result5 = ((ni.Number / 10000) % 10);
                ni.Result6 = ((ni.Number / 100000) % 10);

                int[] array6 = new int[] { ni.Result1, ni.Result2, ni.Result3, ni.Result4, ni.Result5, ni.Result6 };

                array6 = array6.OrderByDescending(c => c).ToArray();

                ni.Value = array6.Aggregate(string.Empty, (s, i) => s + i.ToString());

                ni.Family = Int32.Parse(ni.Value);


            }
            else if (ni.Number < 10000000 && ni.Number >= 1000000)
            {
                ni.Result1 = ((ni.Number / 1) % 10);
                ni.Result2 = ((ni.Number / 10) % 10);
                ni.Result3 = ((ni.Number / 100) % 10);
                ni.Result4 = ((ni.Number / 1000) % 10);
                ni.Result5 = ((ni.Number / 10000) % 10);
                ni.Result6 = ((ni.Number / 100000) % 10);
                ni.Result7 = ((ni.Number / 1000000) % 10);

                int[] array7 = new int[] { ni.Result1, ni.Result2, ni.Result3, ni.Result4, ni.Result5, ni.Result6, ni.Result7 };

                array7 = array7.OrderByDescending(c => c).ToArray();

                ni.Value = array7.Aggregate(string.Empty, (s, i) => s + i.ToString());

                ni.Family = Int32.Parse(ni.Value);

            }
            else if (ni.Number < 100000000 && ni.Number >= 10000000)
            {
                ni.Result1 = ((ni.Number / 1) % 10);
                ni.Result2 = ((ni.Number / 10) % 10);
                ni.Result3 = ((ni.Number / 100) % 10);
                ni.Result4 = ((ni.Number / 1000) % 10);
                ni.Result5 = ((ni.Number / 10000) % 10);
                ni.Result6 = ((ni.Number / 100000) % 10);
                ni.Result7 = ((ni.Number / 1000000) % 10);
                ni.Result8 = ((ni.Number / 10000000) % 10);

                int[] array8 = new int[] { ni.Result1, ni.Result2, ni.Result3, ni.Result4, ni.Result5, ni.Result6, ni.Result7, ni.Result8 };

                array8 = array8.OrderByDescending(c => c).ToArray();

                ni.Value = array8.Aggregate(string.Empty, (s, i) => s + i.ToString());

                ni.Family = Int32.Parse(ni.Value);

            }
            else if (ni.Number == 100000000 )
            {
                ni.Result1 = ((ni.Number / 1) % 10);
                ni.Result2 = ((ni.Number / 10) % 10);
                ni.Result3 = ((ni.Number / 100) % 10);
                ni.Result4 = ((ni.Number / 1000) % 10);
                ni.Result5 = ((ni.Number / 10000) % 10);
                ni.Result6 = ((ni.Number / 100000) % 10);
                ni.Result7 = ((ni.Number / 1000000) % 10);
                ni.Result8 = ((ni.Number / 10000000) % 10);
                ni.Result9 = ((ni.Number / 100000000) % 10);

                int[] array9 = new int[] { ni.Result1, ni.Result2, ni.Result3, ni.Result4, ni.Result5, ni.Result6, ni.Result7, ni.Result8, ni.Result9 };

                array9 = array9.OrderByDescending(c => c).ToArray();

                ni.Value = array9.Aggregate(string.Empty, (s, i) => s + i.ToString());

                ni.Family = Int32.Parse(ni.Value);

            }

            else if (ni.Number > 100000000)
            {
                ni.Result10 = -1;
                ni.Family = ni.Result10;
            }

           
                // Show the family number in outBox:
                outBox.Text = Convert.ToString(ni.Family);
                
            

        }

        private void outBox_TextChanged(object sender, EventArgs e)
        {
            Data ni = new Data();

           
                     

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
