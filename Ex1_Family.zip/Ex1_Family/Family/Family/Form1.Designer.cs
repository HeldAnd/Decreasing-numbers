﻿namespace Family
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.inBox = new System.Windows.Forms.TextBox();
            this.calButton = new System.Windows.Forms.Button();
            this.outBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // inBox
            // 
            this.inBox.Location = new System.Drawing.Point(315, 129);
            this.inBox.Name = "inBox";
            this.inBox.Size = new System.Drawing.Size(164, 26);
            this.inBox.TabIndex = 0;
            this.inBox.TextChanged += new System.EventHandler(this.inBox_TextChanged);
            // 
            // calButton
            // 
            this.calButton.Location = new System.Drawing.Point(343, 180);
            this.calButton.Name = "calButton";
            this.calButton.Size = new System.Drawing.Size(110, 34);
            this.calButton.TabIndex = 1;
            this.calButton.Text = "COMPUTE";
            this.calButton.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.calButton.UseVisualStyleBackColor = true;
            this.calButton.Click += new System.EventHandler(this.calButton_Click);
            // 
            // outBox
            // 
            this.outBox.Location = new System.Drawing.Point(315, 282);
            this.outBox.Name = "outBox";
            this.outBox.Size = new System.Drawing.Size(164, 26);
            this.outBox.TabIndex = 2;
            this.outBox.TextChanged += new System.EventHandler(this.outBox_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(321, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Please, input a value:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(279, 248);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(223, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Family of the number inputted:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.outBox);
            this.Controls.Add(this.calButton);
            this.Controls.Add(this.inBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox inBox;
        private System.Windows.Forms.Button calButton;
        private System.Windows.Forms.TextBox outBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

