﻿namespace Family
{
    public class Data
    {
        private int number;
            public int Number
        {
            get { return this.number; }
            set { this.number = value; }
        }

        private int result1; 
        public int Result1
        {
            get { return this.result1; }
            set { this.result1 = value; }
        }



        private int result2; 
        public int Result2
        {
            get { return this.result2; }
            set { this.result2 = value; }
        }


        private int result3; 
        public int Result3
        {
            get { return this.result3; }
            set { this.result3 = value; }
        }

        private int result4; 
        public int Result4
        {
            get { return this.result4; }
            set { this.result4 = value; }
        }

        private int result5; 
        public int Result5
        {
            get { return this.result5; }
            set { this.result5 = value; }
        }

        private int result6;
        public int Result6
        {
            get { return this.result6; }
            set { this.result6 = value; }
        }

        private int result7;
        public int Result7
        {
            get { return this.result7; }
            set { this.result7 = value; }
        }

        private int result8;
        public int Result8
        {
            get { return this.result8; }
            set { this.result8 = value; }
        }

        private int result9;
        public int Result9
        {
            get { return this.result9; }
            set { this.result9 = value; }
        }

        private int result10;
        public int Result10
        {
            get { return this.result10; }
            set { this.result10 = value; }
        }

        private int solution;
        public int Solution
        {
            get { return this.solution; }
            set { this.solution = value; }
        }

        private string value;
        public string Value
        {
            get { return this.value; }
            set { this.value = value; }
        }

        private int family;
        public int Family
        {
            get { return this.family; }
            set { this.family = value; }
        }


        private bool testS;
        public bool TestS
        {
            get { return this.testS; }
            set { this.testS = value; }
        }


    }
}